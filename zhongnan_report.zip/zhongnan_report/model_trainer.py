"""
模型训练器
使用 LightGBM 训练预测模型
"""
import pandas as pd
import numpy as np
from typing import Tuple, Dict, Any
import json


class SimpleModelTrainer:
    """简化版模型训练器 - 不依赖 LightGBM"""
    
    def __init__(self):
        self.model = None
        self.feature_cols = None
        self.target_col = 'target_return_1d'
    
    def prepare_data(self, df: pd.DataFrame, test_days: int = 50) -> Tuple[pd.DataFrame, pd.DataFrame]:
        """
        准备训练和测试数据
        
        Args:
            df: 带因子的数据
            test_days: 测试集天数
            
        Returns:
            (train_df, test_df)
        """
        # 删除缺失值
        df = df.dropna()
        
        # 划分训练集和测试集
        test_df = df.tail(test_days).copy()
        train_df = df.head(len(df) - test_days).copy()
        
        print(f"训练集: {len(train_df)} 条, 测试集: {len(test_df)} 条")
        return train_df, test_df
    
    def select_features(self, df: pd.DataFrame) -> list:
        """选择特征列"""
        exclude_cols = ['trade_date', 'symbol', 'open', 'high', 'low', 'close', 
                       'volume', 'amount', 'target_return_1d', 'target_return_5d']
        
        feature_cols = [col for col in df.columns if col not in exclude_cols]
        
        # 只选择数值型列
        feature_cols = [col for col in feature_cols 
                       if pd.api.types.is_numeric_dtype(df[col])]
        
        print(f"选择 {len(feature_cols)} 个特征")
        return feature_cols
    
    def train(self, train_df: pd.DataFrame) -> Dict[str, Any]:
        """
        训练模型 - 使用简单线性回归作为基线
        
        Returns:
            训练结果统计
        """
        self.feature_cols = self.select_features(train_df)
        
        X_train = train_df[self.feature_cols].values
        y_train = train_df[self.target_col].values
        
        # 标准化
        self.mean = np.mean(X_train, axis=0)
        self.std = np.std(X_train, axis=0) + 1e-10
        X_train_norm = (X_train - self.mean) / self.std
        
        # 简单线性回归 (使用伪逆)
        self.weights = np.linalg.pinv(X_train_norm.T @ X_train_norm) @ X_train_norm.T @ y_train
        
        # 训练集预测
        y_pred_train = X_train_norm @ self.weights
        
        # 计算指标
        mse = np.mean((y_train - y_pred_train) ** 2)
        mae = np.mean(np.abs(y_train - y_pred_train))
        
        # 方向准确率
        direction_acc = np.mean((y_train > 0) == (y_pred_train > 0))
        
        result = {
            'train_samples': len(train_df),
            'feature_count': len(self.feature_cols),
            'mse': float(mse),
            'mae': float(mae),
            'rmse': float(np.sqrt(mse)),
            'direction_accuracy': float(direction_acc),
        }
        
        print(f"训练完成:")
        print(f"  MSE: {mse:.6f}")
        print(f"  MAE: {mae:.6f}")
        print(f"  方向准确率: {direction_acc:.2%}")
        
        return result
    
    def predict(self, df: pd.DataFrame) -> np.ndarray:
        """预测"""
        X = df[self.feature_cols].values
        X_norm = (X - self.mean) / self.std
        return X_norm @ self.weights
    
    def evaluate(self, test_df: pd.DataFrame) -> Dict[str, Any]:
        """评估模型"""
        y_true = test_df[self.target_col].values
        y_pred = self.predict(test_df)
        
        mse = np.mean((y_true - y_pred) ** 2)
        mae = np.mean(np.abs(y_true - y_pred))
        
        # 方向准确率
        direction_acc = np.mean((y_true > 0) == (y_pred > 0))
        
        # 收益率相关性
        correlation = np.corrcoef(y_true, y_pred)[0, 1]
        
        result = {
            'test_samples': len(test_df),
            'mse': float(mse),
            'mae': float(mae),
            'rmse': float(np.sqrt(mse)),
            'direction_accuracy': float(direction_acc),
            'correlation': float(correlation),
        }
        
        print(f"测试集评估:")
        print(f"  MSE: {mse:.6f}")
        print(f"  MAE: {mae:.6f}")
        print(f"  方向准确率: {direction_acc:.2%}")
        print(f"  相关性: {correlation:.4f}")
        
        return result
    
    def get_feature_importance(self) -> pd.DataFrame:
        """获取特征重要性"""
        importance = np.abs(self.weights)
        importance = importance / importance.sum()
        
        df = pd.DataFrame({
            'feature': self.feature_cols,
            'importance': importance
        }).sort_values('importance', ascending=False)
        
        return df


if __name__ == "__main__":
    # 测试
    np.random.seed(42)
    n = 500
    data = {
        'trade_date': pd.date_range('2024-01-01', periods=n),
        'feature1': np.random.randn(n),
        'feature2': np.random.randn(n),
        'feature3': np.random.randn(n),
        'target_return_1d': np.random.randn(n) * 0.02,
    }
    df = pd.DataFrame(data)
    
    trainer = SimpleModelTrainer()
    train_df, test_df = trainer.prepare_data(df, test_days=50)
    train_result = trainer.train(train_df)
    eval_result = trainer.evaluate(test_df)
    
    importance = trainer.get_feature_importance()
    print("\n特征重要性:")
    print(importance)
