# 中南文化 (002445.SZ) 策略因子分析与模型预测

使用 TickFlow 免费版数据源进行股票因子分析和模型预测。

## 文件说明

| 文件 | 说明 |
|------|------|
| `tickflow_fetcher.py` | TickFlow 数据获取器 |
| `factor_calculator.py` | 策略因子计算器 |
| `model_trainer.py` | 模型训练器 |
| `main_analysis.py` | 主分析程序 |
| `README.md` | 使用说明 |

## 环境要求

```bash
pip install pandas numpy requests
```

## 运行步骤

```bash
# 1. 进入目录
cd zhongnan_report

# 2. 运行分析
python main_analysis.py

# 3. 查看报告
cat zhongnan_culture_report.md
```

## 分析流程

1. **数据获取**: 从 TickFlow 免费 API 获取近2年日线数据
2. **因子计算**: 计算40+技术分析因子
3. **数据划分**: 训练集 + 最近50个交易日测试集
4. **模型训练**: 线性回归模型
5. **模型评估**: MSE、MAE、方向准确率
6. **预测输出**: 预测2026-03-17收益率

## 因子列表

- 价格因子: close_position, body_size, upper_shadow, lower_shadow
- 技术指标: MA, MACD, RSI, BOLL, KDJ
- 波动率: volatility, ATR
- 成交量: volume_ma, OBV, VWAP
- 收益率: return_1d/5d/10d/20d

## 输出报告

运行后会生成 `zhongnan_culture_report.md`，包含:
- 数据概况
- 因子列表
- 模型训练结果
- 测试集评估
- 特征重要性
- 2026-03-17预测结果

## 免责声明

⚠️ 本代码仅供学习研究使用，不构成投资建议。量化交易涉及金融风险，请谨慎决策。

## 参考

- TickFlow 文档: https://docs.tickflow.org/zh-Hans
- 免费 API: https://free-api.tickflow.org
