"""
中南文化 (002445.SZ) 策略因子分析与模型预测
使用 TickFlow 免费版数据源
"""
import pandas as pd
import numpy as np
import json
from datetime import datetime, timedelta
import sys

from tickflow_fetcher import TickFlowFetcher
from factor_calculator import FactorCalculator
from model_trainer import SimpleModelTrainer


def main():
    print("=" * 60)
    print("中南文化 (002445.SZ) 策略因子分析与模型预测")
    print("=" * 60)
    
    # 参数设置
    SYMBOL = "002445.SZ"
    STOCK_NAME = "中南文化"
    END_DATE = "2026-03-17"
    START_DATE = "2024-03-17"  # 2年数据
    TEST_DAYS = 50
    
    print(f"\n股票代码: {SYMBOL}")
    print(f"股票名称: {STOCK_NAME}")
    print(f"数据区间: {START_DATE} ~ {END_DATE}")
    print(f"测试集天数: {TEST_DAYS}")
    
    # 1. 获取数据
    print("\n" + "=" * 60)
    print("步骤 1: 获取日线数据")
    print("=" * 60)
    
    fetcher = TickFlowFetcher()
    df_raw = fetcher.get_daily_quotes(SYMBOL, start_date=START_DATE, end_date=END_DATE)
    
    if df_raw.empty:
        print("错误: 未能获取到数据")
        return
    
    print(f"原始数据: {len(df_raw)} 条")
    print(f"日期范围: {df_raw['trade_date'].min()} ~ {df_raw['trade_date'].max()}")
    
    # 2. 计算因子
    print("\n" + "=" * 60)
    print("步骤 2: 计算策略因子")
    print("=" * 60)
    
    df_factors = FactorCalculator.calculate_all_factors(df_raw)
    print(f"因子计算完成，共 {len(df_factors.columns)} 个字段")
    
    # 3. 数据划分
    print("\n" + "=" * 60)
    print("步骤 3: 数据划分")
    print("=" * 60)
    
    trainer = SimpleModelTrainer()
    train_df, test_df = trainer.prepare_data(df_factors, test_days=TEST_DAYS)
    
    train_start = train_df['trade_date'].min()
    train_end = train_df['trade_date'].max()
    test_start = test_df['trade_date'].min()
    test_end = test_df['trade_date'].max()
    
    print(f"训练集: {train_start} ~ {train_end} ({len(train_df)} 条)")
    print(f"测试集: {test_start} ~ {test_end} ({len(test_df)} 条)")
    
    # 4. 模型训练
    print("\n" + "=" * 60)
    print("步骤 4: 模型训练")
    print("=" * 60)
    
    train_result = trainer.train(train_df)
    
    # 5. 模型评估
    print("\n" + "=" * 60)
    print("步骤 5: 模型评估")
    print("=" * 60)
    
    eval_result = trainer.evaluate(test_df)
    
    # 6. 特征重要性
    print("\n" + "=" * 60)
    print("步骤 6: 特征重要性")
    print("=" * 60)
    
    importance_df = trainer.get_feature_importance()
    print("\nTop 10 重要因子:")
    print(importance_df.head(10).to_string(index=False))
    
    # 7. 预测 2026-03-17
    print("\n" + "=" * 60)
    print("步骤 7: 预测 2026-03-17")
    print("=" * 60)
    
    # 获取最新数据用于预测
    latest_data = df_factors.tail(1).copy()
    prediction = trainer.predict(latest_data)[0]
    latest_price = latest_data['close'].values[0]
    predicted_price = latest_price * (1 + prediction)
    
    print(f"最新交易日: {latest_data['trade_date'].values[0]}")
    print(f"最新收盘价: {latest_price:.2f}")
    print(f"预测收益率: {prediction*100:.2f}%")
    print(f"预测收盘价: {predicted_price:.2f}")
    
    # 8. 生成报告
    print("\n" + "=" * 60)
    print("步骤 8: 生成报告")
    print("=" * 60)
    
    report = generate_report(
        stock_name=STOCK_NAME,
        symbol=SYMBOL,
        df_raw=df_raw,
        df_factors=df_factors,
        train_result=train_result,
        eval_result=eval_result,
        importance_df=importance_df,
        prediction=prediction,
        latest_price=latest_price,
        predicted_price=predicted_price,
        latest_date=latest_data['trade_date'].values[0],
        train_start=train_start,
        train_end=train_end,
        test_start=test_start,
        test_end=test_end
    )
    
    # 保存报告
    report_file = "zhongnan_culture_report.md"
    with open(report_file, 'w', encoding='utf-8') as f:
        f.write(report)
    
    print(f"\n报告已保存: {report_file}")
    print("\n" + "=" * 60)
    print("分析完成!")
    print("=" * 60)


def generate_report(**kwargs) -> str:
    """生成 Markdown 报告"""
    
    report = f"""# 中南文化 (002445.SZ) 策略因子分析与模型预测报告

**生成时间**: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}  
**数据来源**: TickFlow 免费版 API  
**分析方法**: 技术分析因子 + 线性回归模型

---

## 1. 数据概况

| 项目 | 内容 |
|------|------|
| 股票名称 | {kwargs['stock_name']} |
| 股票代码 | {kwargs['symbol']} |
| 数据区间 | {kwargs['df_raw']['trade_date'].min()} ~ {kwargs['df_raw']['trade_date'].max()} |
| 数据条数 | {len(kwargs['df_raw'])} 个交易日 |
| 最新收盘价 | {kwargs['latest_price']:.2f} 元 |

### 价格统计

| 指标 | 数值 |
|------|------|
| 最高价 | {kwargs['df_raw']['high'].max():.2f} |
| 最低价 | {kwargs['df_raw']['low'].min():.2f} |
| 平均成交量 | {kwargs['df_raw']['volume'].mean():.0f} |
| 平均成交额 | {kwargs['df_raw']['amount'].mean():.0f} |

---

## 2. 策略因子

### 因子列表

共计算 **{len([c for c in kwargs['df_factors'].columns if c not in ['trade_date', 'symbol', 'open', 'high', 'low', 'close', 'volume', 'amount']])}** 个因子，包括：

**价格因子**:
- `close_position`: 收盘价在当日价格区间位置
- `body_size`: K线实体大小
- `upper_shadow`: 上影线比例
- `lower_shadow`: 下影线比例

**技术指标因子**:
- `ma_5/10/20/60`: 移动平均线
- `macd`: MACD指标
- `rsi_14`: RSI相对强弱指标
- `boll_upper/mid/lower`: 布林带
- `kdj_k/d/j`: KDJ指标

**波动率因子**:
- `volatility_5/10/20`: 历史波动率
- `atr_14`: 平均真实波幅

**成交量因子**:
- `volume_ma_5/10/20`: 成交量均线
- `volume_ratio_5/10/20`: 成交量比率
- `obv`: 能量潮指标
- `vwap`: 成交量加权平均价

**收益率因子**:
- `return_1d/5d/10d/20d`: 历史收益率
- `target_return_1d/5d`: 未来收益率(目标变量)

---

## 3. 模型训练

### 数据集划分

| 数据集 | 日期范围 | 样本数 |
|--------|----------|--------|
| 训练集 | {kwargs['train_start']} ~ {kwargs['train_end']} | {kwargs['train_result']['train_samples']} |
| 测试集 | {kwargs['test_start']} ~ {kwargs['test_end']} | {kwargs['eval_result']['test_samples']} |

### 训练结果

| 指标 | 训练集 | 测试集 |
|------|--------|--------|
| MSE | {kwargs['train_result']['mse']:.6f} | {kwargs['eval_result']['mse']:.6f} |
| MAE | {kwargs['train_result']['mae']:.6f} | {kwargs['eval_result']['mae']:.6f} |
| RMSE | {kwargs['train_result']['rmse']:.6f} | {kwargs['eval_result']['rmse']:.6f} |
| 方向准确率 | {kwargs['train_result']['direction_accuracy']:.2%} | {kwargs['eval_result']['direction_accuracy']:.2%} |
| 收益率相关性 | - | {kwargs['eval_result']['correlation']:.4f} |

### 特征重要性 Top 10

| 排名 | 因子 | 重要性 |
|------|------|--------|
"""
    
    for i, row in kwargs['importance_df'].head(10).iterrows():
        rank = kwargs['importance_df'].index.get_loc(i) + 1
        report += f"| {rank} | {row['feature']} | {row['importance']:.4f} |\n"
    
    report += f"""
---

## 4. 预测结果

### 2026-03-17 预测

| 项目 | 数值 |
|------|------|
| 最新交易日 | {kwargs['latest_date']} |
| 最新收盘价 | {kwargs['latest_price']:.2f} 元 |
| 预测收益率 | **{kwargs['prediction']*100:.2f}%** |
| 预测收盘价 | **{kwargs['predicted_price']:.2f} 元** |

### 预测说明

- 模型基于历史 {kwargs['train_result']['train_samples']} 个交易日数据训练
- 预测目标为下一个交易日的收益率
- 方向准确率在测试集上为 {kwargs['eval_result']['direction_accuracy']:.2%}

---

## 5. 风险提示

> ⚠️ **免责声明**: 
> 1. 本报告仅供学习研究使用，不构成投资建议
> 2. 模型预测结果存在不确定性，过往表现不代表未来收益
> 3. 量化交易涉及金融风险，请谨慎决策
> 4. 使用 TickFlow 免费版数据，可能存在延迟

---

## 附录: 使用说明

### 运行环境要求

```bash
pip install pandas numpy requests
```

### 运行命令

```bash
python main_analysis.py
```

### 输出文件

- `zhongnan_culture_report.md`: 分析报告
- `zhongnan_culture_data.csv`: 原始数据(可选保存)

---

*报告由 Quant Assistant 自动生成*
"""
    
    return report


if __name__ == "__main__":
    main()
