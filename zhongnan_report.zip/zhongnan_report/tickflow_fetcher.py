"""
TickFlow 数据获取器 - 独立版本
无需安装 quant_assistant，可直接运行
"""
import requests
import pandas as pd
from datetime import datetime, date, timedelta
from typing import Optional, List, Dict, Any
import time
import json


class TickFlowFetcher:
    """
    TickFlow 数据获取器 - 免费版
    
    免费服务地址: https://free-api.tickflow.org
    支持日K线数据、财务数据等
    """
    
    FREE_API_BASE = "https://free-api.tickflow.org"
    
    def __init__(self):
        self.name = "TickFlow"
        self.base_url = self.FREE_API_BASE
        self.rate_limit_delay = 0.5
    
    def _rate_limit(self):
        time.sleep(self.rate_limit_delay)
    
    def _request(self, endpoint: str, params: Optional[Dict] = None) -> Dict[str, Any]:
        """发送 HTTP 请求"""
        url = f"{self.base_url}{endpoint}"
        headers = {'Accept': 'application/json'}
        
        try:
            self._rate_limit()
            response = requests.get(url, params=params, headers=headers, timeout=30)
            response.raise_for_status()
            return response.json()
        except Exception as e:
            print(f"请求失败: {url}, 错误: {e}")
            raise
    
    def _convert_symbol(self, symbol: str) -> str:
        """转换股票代码格式"""
        symbol = symbol.upper().strip()
        if '.' in symbol:
            return symbol
        
        if symbol.startswith(('600', '601', '603', '605', '688', '689')):
            return f"{symbol}.SH"
        elif symbol.startswith(('000', '001', '002', '003', '300', '301')):
            return f"{symbol}.SZ"
        elif symbol.startswith(('8', '4', '92')):
            return f"{symbol}.BJ"
        else:
            return f"{symbol}.SZ"
    
    def get_daily_quotes(self, symbol: str, start_date: Optional[str] = None, 
                         end_date: Optional[str] = None) -> pd.DataFrame:
        """获取日线行情数据"""
        symbol = self._convert_symbol(symbol)
        
        params = {'symbol': symbol, 'period': '1d'}
        if start_date:
            params['start'] = start_date
        if end_date:
            params['end'] = end_date
        
        print(f"获取 {symbol} 日线数据: {start_date} ~ {end_date}")
        data = self._request('/v1/klines', params)
        klines = data.get('klines', [])
        
        if not klines:
            print(f"{symbol} 无数据")
            return pd.DataFrame()
        
        df = pd.DataFrame(klines)
        df = df.rename(columns={
            'timestamp': 'trade_date',
            'open': 'open',
            'high': 'high',
            'low': 'low',
            'close': 'close',
            'volume': 'volume',
            'amount': 'amount',
        })
        
        df['trade_date'] = pd.to_datetime(df['trade_date']).dt.date
        df['symbol'] = symbol.split('.')[0]
        
        print(f"获取到 {len(df)} 条数据")
        return df


if __name__ == "__main__":
    # 测试
    fetcher = TickFlowFetcher()
    df = fetcher.get_daily_quotes('002445.SZ', start_date='2024-03-01', end_date='2024-03-10')
    print(df.head())
