"""
策略因子计算器
计算常用的技术分析因子
"""
import pandas as pd
import numpy as np


class FactorCalculator:
    """因子计算器"""
    
    @staticmethod
    def calculate_all_factors(df: pd.DataFrame) -> pd.DataFrame:
        """计算所有因子"""
        df = df.copy()
        df = df.sort_values('trade_date').reset_index(drop=True)
        
        # 价格因子
        df = FactorCalculator._price_factors(df)
        
        # 技术指标因子
        df = FactorCalculator._technical_factors(df)
        
        # 波动率因子
        df = FactorCalculator._volatility_factors(df)
        
        # 成交量因子
        df = FactorCalculator._volume_factors(df)
        
        # 收益率因子
        df = FactorCalculator._return_factors(df)
        
        return df
    
    @staticmethod
    def _price_factors(df: pd.DataFrame) -> pd.DataFrame:
        """价格因子"""
        # 收盘价位置
        df['close_position'] = (df['close'] - df['low']) / (df['high'] - df['low'] + 1e-10)
        
        # 实体大小
        df['body_size'] = abs(df['close'] - df['open']) / (df['high'] - df['low'] + 1e-10)
        
        # 上影线/下影线
        df['upper_shadow'] = (df['high'] - df[['close', 'open']].max(axis=1)) / (df['high'] - df['low'] + 1e-10)
        df['lower_shadow'] = (df[['close', 'open']].min(axis=1) - df['low']) / (df['high'] - df['low'] + 1e-10)
        
        return df
    
    @staticmethod
    def _technical_factors(df: pd.DataFrame) -> pd.DataFrame:
        """技术指标因子"""
        # MA 均线
        for window in [5, 10, 20, 60]:
            df[f'ma_{window}'] = df['close'].rolling(window=window).mean()
            df[f'ma_ratio_{window}'] = df['close'] / df[f'ma_{window}']
        
        # MACD
        exp1 = df['close'].ewm(span=12, adjust=False).mean()
        exp2 = df['close'].ewm(span=26, adjust=False).mean()
        df['macd'] = exp1 - exp2
        df['macd_signal'] = df['macd'].ewm(span=9, adjust=False).mean()
        df['macd_hist'] = df['macd'] - df['macd_signal']
        
        # RSI
        delta = df['close'].diff()
        gain = (delta.where(delta > 0, 0)).rolling(window=14).mean()
        loss = (-delta.where(delta < 0, 0)).rolling(window=14).mean()
        rs = gain / (loss + 1e-10)
        df['rsi_14'] = 100 - (100 / (1 + rs))
        
        # BOLL
        df['boll_mid'] = df['close'].rolling(window=20).mean()
        df['boll_std'] = df['close'].rolling(window=20).std()
        df['boll_upper'] = df['boll_mid'] + 2 * df['boll_std']
        df['boll_lower'] = df['boll_mid'] - 2 * df['boll_std']
        df['boll_position'] = (df['close'] - df['boll_lower']) / (df['boll_upper'] - df['boll_lower'] + 1e-10)
        
        # KDJ
        low_list = df['low'].rolling(window=9, min_periods=9).min()
        high_list = df['high'].rolling(window=9, min_periods=9).max()
        rsv = (df['close'] - low_list) / (high_list - low_list + 1e-10) * 100
        df['kdj_k'] = rsv.ewm(alpha=1/3, adjust=False).mean()
        df['kdj_d'] = df['kdj_k'].ewm(alpha=1/3, adjust=False).mean()
        df['kdj_j'] = 3 * df['kdj_k'] - 2 * df['kdj_d']
        
        return df
    
    @staticmethod
    def _volatility_factors(df: pd.DataFrame) -> pd.DataFrame:
        """波动率因子"""
        # 日收益率
        df['daily_return'] = df['close'].pct_change()
        
        # 波动率
        for window in [5, 10, 20]:
            df[f'volatility_{window}'] = df['daily_return'].rolling(window=window).std()
        
        # ATR
        df['tr1'] = df['high'] - df['low']
        df['tr2'] = abs(df['high'] - df['close'].shift(1))
        df['tr3'] = abs(df['low'] - df['close'].shift(1))
        df['tr'] = df[['tr1', 'tr2', 'tr3']].max(axis=1)
        df['atr_14'] = df['tr'].rolling(window=14).mean()
        
        return df
    
    @staticmethod
    def _volume_factors(df: pd.DataFrame) -> pd.DataFrame:
        """成交量因子"""
        # 成交量均线
        for window in [5, 10, 20]:
            df[f'volume_ma_{window}'] = df['volume'].rolling(window=window).mean()
            df[f'volume_ratio_{window}'] = df['volume'] / df[f'volume_ma_{window}']
        
        # OBV
        df['obv'] = (np.sign(df['close'].diff()) * df['volume']).cumsum()
        
        # VWAP
        df['vwap'] = (df['amount'] / df['volume']).fillna(df['close'])
        df['vwap_ratio'] = df['close'] / df['vwap']
        
        return df
    
    @staticmethod
    def _return_factors(df: pd.DataFrame) -> pd.DataFrame:
        """收益率因子"""
        # 未来收益率 (作为目标变量)
        df['target_return_1d'] = df['close'].shift(-1) / df['close'] - 1
        df['target_return_5d'] = df['close'].shift(-5) / df['close'] - 1
        
        # 历史收益率
        for window in [1, 5, 10, 20]:
            df[f'return_{window}d'] = df['close'].pct_change(window)
        
        return df


if __name__ == "__main__":
    # 测试
    import pandas as pd
    data = {
        'trade_date': pd.date_range('2024-01-01', periods=100),
        'open': np.random.randn(100).cumsum() + 10,
        'high': np.random.randn(100).cumsum() + 11,
        'low': np.random.randn(100).cumsum() + 9,
        'close': np.random.randn(100).cumsum() + 10,
        'volume': np.random.randint(1000, 10000, 100),
        'amount': np.random.randint(100000, 1000000, 100),
    }
    df = pd.DataFrame(data)
    df['high'] = df[['open', 'high', 'close']].max(axis=1)
    df['low'] = df[['open', 'low', 'close']].min(axis=1)
    
    result = FactorCalculator.calculate_all_factors(df)
    print(f"因子数量: {len(result.columns)}")
    print(result.columns.tolist())
